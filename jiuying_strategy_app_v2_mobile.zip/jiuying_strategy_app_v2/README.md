# 九盈探索 A股策略助手 v2（手机查看版）

## 版本定位
这是可在手机浏览器访问的 Streamlit 网页 App 项目。项目文件已生成，但尚未替你部署到公开网址。部署后用手机打开网址即可查看；当前不自动下单。

## 本地运行
Python 3.10/3.11：
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 云端部署（手机访问）
Streamlit Community Cloud 的基本流程：
1. 将本文件夹内容上传到你自己的 GitHub 仓库。
2. 在 Streamlit Community Cloud 创建 App，选择仓库、分支和 `app.py`。
3. 部署完成后用手机浏览器打开生成的网址。
4. 仓库设为公开时不要放入账号密码、API密钥或个人数据。

官方部署说明：https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app

## 每日自动刷新
页面里的“刷新行情”是手动操作。想每天自动刷新，需将 `run_daily.py` 放在一台持续运行的云主机/定时任务中，并保存报告到持久化存储；普通临时容器重启后本地文件可能丢失。部署到 Streamlit 并不等于自动定时运行。

## 近三年回测
目标区间默认建议为 2023-10-23 至 2026-10-22。上传 5 分钟 CSV，必需列：
`date,code,datetime,open,high,low,close,volume`
可选列：`amount,prev_close,volume_ratio`。

重要：策略引擎要求 `volume_ratio` 为可核实的历史同时间量比；没有时不会用伪指标替代，因而不会产生交易信号。回测引擎目前是研究原型，不是生产级交易模拟器；它还没有完全模拟涨停排队、跌停无法卖出、停牌、历史ST状态、退市股票和组合逐日市值。必须完成这些部分并核验数据质量后，才能评估策略表现。

AKShare 分钟接口的历史覆盖有限且会随接口变化。不能把请求了三年等同于获得了三年数据。参考：
- AKShare 分钟数据文档：https://akshare-hh.readthedocs.io/en/latest/data/stock/stock.html
- AKShare GitHub issue：https://github.com/akfamily/akshare/issues/5884
- AKShare GitHub issue：https://github.com/akfamily/akshare/issues/5971

## 规则映射
- 主板普通股近似筛选（代码前缀+当前名称排除ST）
- 股价 5–85 元，涨幅 5%–8%，量比 ≥2.5
- 盘中信号研究原型：09:35–14:30、站上当日VWAP、突破前6根5分钟K线高点
- 下一根5分钟K线开盘价成交并加滑点；持仓次日开盘简化退出，符合 T+1 研究约束
- 单笔风险预算默认 0.5%，单票仓位上限 25%

## 风险声明
不构成投资建议。历史模拟不代表未来收益。请勿直接采用截图中的满仓规则；在真实使用前先做样本外测试与成本敏感性分析。
