from datetime import datetime
from pathlib import Path
import json
import pandas as pd
import numpy as np
import akshare as ak

REPORT_DIR = Path("reports")
REPORT_DIR.mkdir(exist_ok=True)

def _find_col(df, names):
    for name in names:
        if name in df.columns:
            return name
    return None

def fetch_market_snapshot():
    fetched_at = datetime.now().astimezone().isoformat(timespec="seconds")
    spot = ak.stock_zh_a_spot_em()
    if spot is None or spot.empty:
        raise RuntimeError("A股行情接口返回空数据")
    spot = spot.copy()
    mapping = {
        "代码": ["代码", "股票代码"], "名称": ["名称", "股票简称"],
        "最新价": ["最新价", "现价"], "涨跌幅": ["涨跌幅"],
        "量比": ["量比"], "换手率": ["换手率"], "成交额": ["成交额"],
        "最高": ["最高"], "最低": ["最低"], "今开": ["今开"], "昨收": ["昨收"]
    }
    rename = {}
    for target, choices in mapping.items():
        found = _find_col(spot, choices)
        if found and found != target:
            rename[found] = target
    spot.rename(columns=rename, inplace=True)
    for col in mapping:
        if col not in spot.columns:
            spot[col] = np.nan
    spot["代码"] = spot["代码"].astype(str).str.zfill(6)
    for col in ["最新价", "涨跌幅", "量比", "换手率", "成交额", "最高", "最低", "今开", "昨收"]:
        spot[col] = pd.to_numeric(spot[col], errors="coerce")

    indices, warnings = [], []
    for code, name in [("sh000001", "上证指数"), ("sz399001", "深证成指")]:
        try:
            hist = ak.stock_zh_index_daily_em(symbol=code)
            close_col = _find_col(hist, ["close", "收盘"])
            date_col = _find_col(hist, ["date", "日期"])
            if hist is None or hist.empty or close_col is None:
                raise RuntimeError("接口无可用收盘价字段")
            close = pd.to_numeric(hist[close_col], errors="coerce").dropna()
            if len(close) < 5:
                raise RuntimeError("指数历史数据不足")
            latest = float(close.iloc[-1])
            prev = float(close.iloc[-2])
            indices.append({"name": name, "latest_close": latest,
                            "daily_change_pct": (latest / prev - 1) * 100,
                            "above_ma5": latest >= float(close.tail(5).mean()),
                            "date": str(hist[date_col].iloc[-1]) if date_col else "未知"})
        except Exception as e:
            warnings.append(f"{name}读取失败：{e}")
    return spot, indices, {"fetched_at": fetched_at, "warnings": warnings}

def build_market_diagnosis(indices, snapshot, meta):
    changes = pd.to_numeric(snapshot["涨跌幅"], errors="coerce")
    adv = int((changes > 0).sum())
    dec = int((changes < 0).sum())
    amount = pd.to_numeric(snapshot["成交额"], errors="coerce").sum(min_count=1)
    warnings = list(meta.get("warnings", []))
    if not indices:
        status, summary = "数据不足", "指数数据不可用，暂不对大盘方向下结论。"
        warnings.append("大盘方向未能判定；建议暂停依赖该判断的策略信号。")
    else:
        score = sum((1 if x["daily_change_pct"] > 0 else -1 if x["daily_change_pct"] < 0 else 0)
                    + (1 if x["above_ma5"] else -1) for x in indices)
        breadth = adv - dec
        if score >= 2 and breadth > 0:
            status, summary = "偏强", "指数短线方向与个股涨跌广度偏正面，但仍需确认成交额、涨停结构和盘中承接。"
        elif score <= -2 and breadth < 0:
            status, summary = "偏弱", "指数方向或市场广度偏弱，降低追涨频率，等待确认信号。"
        else:
            status, summary = "震荡/分化", "指数与个股广度信号不一致或不够明确，建议降低频率、等待更清晰突破。"
    amount_label = "未知" if pd.isna(amount) else f"{amount/1e8:.2f} 亿元"
    return {"status": status, "summary": summary, "advancers": adv, "decliners": dec,
            "total_amount": amount_label, "indices": indices, "warnings": warnings, "meta": meta}

def screen_candidates(snapshot, min_price=5, max_price=85, min_gain=5, max_gain=8,
                      min_volume_ratio=2.5, market_status="未知"):
    df = snapshot.copy()
    df["代码"] = df["代码"].astype(str).str.zfill(6)
    for col in ["最新价", "涨跌幅", "量比"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    mainboard = df["代码"].str.startswith(("600", "601", "603", "605", "000", "001", "002", "003"))
    not_st = ~df["名称"].astype(str).str.upper().str.contains(r"ST|\*ST", regex=True, na=False)
    mask = (mainboard & not_st & df["最新价"].between(min_price, max_price)
            & df["涨跌幅"].between(min_gain, max_gain) & (df["量比"] >= min_volume_ratio))
    out = df.loc[mask].copy()
    out["信号说明"] = "仅符合快照初筛；盘中VWAP与前高突破尚未验证"
    out["风险提示"] = "需核对盘中形态、历史ST/一字板、停牌及涨停可成交性"
    if market_status == "偏弱":
        out["风险提示"] = "大盘偏弱，仅作观察；" + out["风险提示"]
    if market_status == "数据不足":
        out["风险提示"] = "大盘数据不足；" + out["风险提示"]
    return out.sort_values(["量比", "涨跌幅"], ascending=False).reset_index(drop=True)

def save_daily_report(diag, candidates, params):
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = REPORT_DIR / f"candidates_{stamp}.csv"
    json_path = REPORT_DIR / f"report_{stamp}.json"
    candidates.to_csv(csv_path, index=False, encoding="utf-8-sig")
    payload = {"created_at": datetime.now().astimezone().isoformat(), "diagnosis": diag,
               "parameters": params, "candidate_count": len(candidates), "candidate_file": str(csv_path)}
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(json_path)
