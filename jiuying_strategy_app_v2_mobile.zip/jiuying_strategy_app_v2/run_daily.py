from strategy_engine import fetch_market_snapshot, build_market_diagnosis, screen_candidates, save_daily_report

def main():
    snapshot, indices, meta = fetch_market_snapshot()
    diag = build_market_diagnosis(indices, snapshot, meta)
    candidates = screen_candidates(snapshot, market_status=diag.get("status", "未知"))
    print(save_daily_report(diag, candidates, {
        "min_price": 5, "max_price": 85, "min_gain": 5, "max_gain": 8,
        "min_volume_ratio": 2.5
    }))
    print(f"市场状态：{diag['status']}；候选数：{len(candidates)}")

if __name__ == "__main__":
    main()
