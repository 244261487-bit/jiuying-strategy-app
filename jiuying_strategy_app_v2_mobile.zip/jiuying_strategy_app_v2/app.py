from pathlib import Path
from datetime import datetime
import json
import pandas as pd
import streamlit as st
from strategy_engine import fetch_market_snapshot, build_market_diagnosis, screen_candidates, save_daily_report
from backtest_engine import run_backtest, validate_5m_data

st.set_page_config(page_title="九盈探索", page_icon="📈", layout="wide", initial_sidebar_state="collapsed")

st.markdown("""
<style>
.block-container {padding-top: 1rem; padding-bottom: 2rem; max-width: 1150px;}
[data-testid="stMetric"] {background: rgba(128,128,128,.08); padding: .7rem; border-radius: .7rem;}
.stButton button, .stDownloadButton button {min-height: 2.7rem; width: 100%; border-radius: .65rem;}
@media (max-width: 640px) {
  .block-container {padding-left: .75rem; padding-right: .75rem;}
  h1 {font-size: 1.6rem !important;}
  h2 {font-size: 1.25rem !important;}
}
</style>
""", unsafe_allow_html=True)

st.title("📈 九盈探索")
st.caption("A股每日策略助手 · 手机浏览器友好版 · 研究用途，不自动下单")

data_dir = Path("data")
reports_dir = Path("reports")
data_dir.mkdir(exist_ok=True)
reports_dir.mkdir(exist_ok=True)
snapshot_path = data_dir / "latest_snapshot.csv"
diag_path = data_dir / "latest_diagnosis.json"

tab_today, tab_backtest, tab_history, tab_about = st.tabs(["📊 今日策略", "🧪 回测", "🗂️ 报告记录", "⚙️ 使用说明"])

with tab_today:
    st.subheader("每日市场诊断")
    col1, col2 = st.columns([1, 1])
    with col1:
        if st.button("🔄 刷新行情", type="primary"):
            try:
                with st.spinner("正在获取公开行情…"):
                    snapshot, indices, meta = fetch_market_snapshot()
                    snapshot.to_csv(snapshot_path, index=False, encoding="utf-8-sig")
                    diag = build_market_diagnosis(indices, snapshot, meta)
                    diag_path.write_text(json.dumps(diag, ensure_ascii=False, indent=2), encoding="utf-8")
                st.success("行情刷新完成")
            except Exception as exc:
                st.error(f"获取失败：{exc}")
    with col2:
        if snapshot_path.exists():
            st.caption("已有本地快照；请检查数据时间，旧快照不代表今天行情。")
        else:
            st.caption("首次使用请先刷新行情。")

    with st.expander("筛选参数", expanded=False):
        a, b = st.columns(2)
        with a:
            min_price = st.number_input("最低股价（元）", 0.1, 1000.0, 5.0, 0.5)
            min_gain = st.number_input("最低涨幅（%）", -10.0, 20.0, 5.0, 0.5)
            min_vr = st.number_input("最低量比", 0.1, 20.0, 2.5, 0.1)
        with b:
            max_price = st.number_input("最高股价（元）", 0.1, 2000.0, 85.0, 1.0)
            max_gain = st.number_input("最高涨幅（%）", -10.0, 30.0, 8.0, 0.5)
            max_rows = st.number_input("最多显示候选股", 5, 100, 30, 5)

    if snapshot_path.exists():
        snapshot = pd.read_csv(snapshot_path, dtype={"代码": str})
        diag = json.loads(diag_path.read_text(encoding="utf-8")) if diag_path.exists() else {}
        st.caption(f"行情时间：{diag.get('meta', {}).get('fetched_at', '未知')} · 来源：AkShare公开接口")
        m1, m2, m3 = st.columns(3)
        m1.metric("市场环境", diag.get("status", "未知"))
        m2.metric("上涨家数", diag.get("advancers", "—"))
        m3.metric("下跌家数", diag.get("decliners", "—"))
        st.info(diag.get("summary", "暂无诊断"))
        for warning in diag.get("warnings", []):
            st.warning(warning)

        candidates = screen_candidates(snapshot, min_price, max_price, min_gain, max_gain, min_vr, diag.get("status", "未知"))
        st.subheader(f"候选观察名单（{len(candidates)} 只）")
        st.caption("这是条件初筛，不是买入指令；未用盘中5分钟数据验证突破与VWAP。")
        if candidates.empty:
            st.warning("当前没有符合初筛条件的股票，或行情字段不完整。")
        else:
            cols = [c for c in ["代码", "名称", "最新价", "涨跌幅", "量比", "换手率", "信号说明", "风险提示"] if c in candidates]
            st.dataframe(candidates[cols].head(int(max_rows)), use_container_width=True, hide_index=True)
            st.download_button("下载候选名单 CSV", candidates.to_csv(index=False).encode("utf-8-sig"),
                               f"jiuying_candidates_{datetime.now():%Y%m%d}.csv", "text/csv")
        if st.button("保存今日报告"):
            p = save_daily_report(diag, candidates, {"min_price": min_price, "max_price": max_price,
                "min_gain": min_gain, "max_gain": max_gain, "min_volume_ratio": min_vr})
            st.success(f"已保存：{p}")
    else:
        st.warning("还没有行情快照。点击“刷新行情”开始。")

with tab_backtest:
    st.subheader("近三年策略回测")
    st.warning("半路板是盘中策略，严格回测需要历史5分钟数据。请上传符合格式的CSV；本页面不会把日线回测冒充成盘中策略回测。")
    st.markdown("CSV必需列：`date, code, datetime, open, high, low, close, volume`；可选列：`amount, prev_close, volume_ratio`。每行一根5分钟K线，时间为中国交易所本地时间。")
    uploaded = st.file_uploader("上传5分钟K线 CSV", type=["csv"], key="bars_upload")
    if uploaded is not None:
        try:
            bars = pd.read_csv(uploaded, dtype={"code": str})
            ok, messages = validate_5m_data(bars)
            for msg in messages:
                (st.success if ok else st.warning)(msg)
            if ok:
                start = st.date_input("回测开始日期", value=pd.Timestamp("2023-10-23").date())
                end = st.date_input("回测结束日期", value=pd.Timestamp("2026-10-22").date())
                c1, c2, c3 = st.columns(3)
                with c1:
                    initial_cash = st.number_input("初始资金（元）", 10000, 100000000, 1000000, 10000)
                with c2:
                    risk_pct = st.number_input("单笔风险预算（%）", 0.1, 2.0, 0.5, 0.1)
                with c3:
                    position_cap = st.number_input("单票仓位上限（%）", 1, 100, 25, 1)
                if st.button("运行5分钟策略回测", type="primary"):
                    with st.spinner("回测运行中…"):
                        result = run_backtest(bars, str(start), str(end), initial_cash, risk_pct/100, position_cap/100)
                    st.subheader("回测摘要")
                    a, b, c = st.columns(3)
                    a.metric("交易笔数", result["metrics"]["trades"])
                    b.metric("总收益", f'{result["metrics"]["total_return_pct"]:.2f}%')
                    c.metric("最大回撤", f'{result["metrics"]["max_drawdown_pct"]:.2f}%')
                    st.json(result["metrics"])
                    st.dataframe(result["trades"].head(500), use_container_width=True, hide_index=True)
                    st.download_button("下载交易记录", result["trades"].to_csv(index=False).encode("utf-8-sig"),
                                       "jiuying_backtest_trades.csv", "text/csv")
                    st.download_button("下载权益曲线", result["equity"].to_csv(index=False).encode("utf-8-sig"),
                                       "jiuying_equity_curve.csv", "text/csv")
        except Exception as exc:
            st.error(f"CSV读取或回测失败：{exc}")

with tab_history:
    st.subheader("历史报告")
    paths = sorted(reports_dir.glob("report_*.json"), reverse=True)
    if not paths:
        st.caption("暂时没有保存的报告。")
    else:
        for p in paths[:30]:
            with st.expander(p.name):
                try:
                    obj = json.loads(p.read_text(encoding="utf-8"))
                    st.write(obj.get("diagnosis", {}).get("summary", ""))
                    st.write(f"候选股数量：{obj.get('candidate_count', '未知')}")
                    st.json(obj.get("parameters", {}))
                except Exception as exc:
                    st.error(str(exc))

with tab_about:
    st.subheader("规则来源与限制")
    st.markdown("""
- 初筛规则来自你提供的“九盈探索”截图：主板、非ST、股价5–85元、涨幅5%–8%、量比大于2.5。
- 完整盘中规则还需要验证：09:35–14:30、站上VWAP、突破此前高点、量能放大等。
- 目前的实时快照初筛不能代替盘中信号；历史ST状态、退市股票和历史证券名单需要专门历史数据。
- A股T+1、涨跌停、停牌、手续费、印花税和滑点都会影响结果。5分钟OHLC无法精确模拟涨停排队。
- 回测结果是历史模拟，不保证未来表现。请先做样本外验证，不建议照搬满仓规则。
    """)
    st.markdown("**手机访问**：将项目部署到云端后，用手机浏览器打开部署网址即可。当前项目本身不会自动上线，也不会连接券商下单。")
