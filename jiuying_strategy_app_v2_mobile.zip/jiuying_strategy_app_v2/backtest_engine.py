import pandas as pd
import numpy as np

REQUIRED = ["date", "code", "datetime", "open", "high", "low", "close", "volume"]

def validate_5m_data(df):
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        return False, [f"缺少必需列：{', '.join(missing)}"]
    msgs = []
    if df.empty:
        return False, ["CSV为空"]
    dt = pd.to_datetime(df["datetime"], errors="coerce")
    if dt.isna().any():
        return False, ["datetime存在无法解析的值"]
    for c in ["open", "high", "low", "close", "volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if df[["open","high","low","close","volume"]].isna().any().any():
        return False, ["OHLCV存在缺失或非数字值"]
    if (df["high"] < df[["open","close","low"]].max(axis=1)).any():
        return False, ["发现 high 小于 open/close/low 的异常行"]
    if (df["low"] > df[["open","close","high"]].min(axis=1)).any():
        return False, ["发现 low 大于 open/close/high 的异常行"]
    msgs.append(f"数据格式检查通过：{len(df):,} 根K线；日期范围 {dt.min()} 至 {dt.max()}")
    if "prev_close" not in df.columns:
        msgs.append("未提供 prev_close：涨幅过滤将按前一交易日收盘价推算，可能受复权/缺失影响")
    return True, msgs

def _commission(notional, side):
    # Research defaults only; adjust to the actual broker and current rules.
    commission = max(notional * 0.0003, 5.0)
    stamp = notional * 0.0005 if side == "sell" else 0.0
    return commission + stamp

def run_backtest(raw, start, end, initial_cash=1_000_000, risk_fraction=0.005, position_cap=0.25):
    """
    Conservative bar-based research backtest:
    signal on completed bar, enter next bar open + slippage.
    One position at a time per symbol; portfolio permits multiple symbols but caps each.
    Simplified limit-up/limit-down queue and suspension handling are NOT fully modeled.
    """
    df = raw.copy()
    df["datetime"] = pd.to_datetime(df["datetime"])
    df["date"] = pd.to_datetime(df["date"]).dt.date.astype(str)
    df["code"] = df["code"].astype(str).str.zfill(6)
    for c in ["open","high","low","close","volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df[(df["date"] >= str(start)) & (df["date"] <= str(end))]
    df = df.sort_values(["code","datetime"]).reset_index(drop=True)
    if df.empty:
        raise ValueError("所选区间没有数据")
    if "prev_close" in df.columns:
        df["prev_close"] = pd.to_numeric(df["prev_close"], errors="coerce")
    else:
        daily_close = df.groupby(["code","date"])["close"].last().rename("day_close").reset_index()
        daily_close["prev_close"] = daily_close.groupby("code")["day_close"].shift(1)
        df = df.merge(daily_close[["code","date","prev_close"]], on=["code","date"], how="left")
    if "amount" in df.columns:
        df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
    else:
        df["amount"] = df["close"] * df["volume"]
    df["pct_change"] = (df["close"] / df["prev_close"] - 1) * 100
    df["bar_no"] = df.groupby(["code","date"]).cumcount()
    df["cum_vol"] = df.groupby(["code","date"])["volume"].cumsum()
    df["cum_amount"] = df.groupby(["code","date"])["amount"].cumsum()
    df["vwap"] = df["cum_amount"] / df["cum_vol"].replace(0, np.nan)
    df["prior_high6"] = df.groupby(["code","date"])["high"].transform(
        lambda s: s.shift(1).rolling(6, min_periods=6).max())
    if "volume_ratio" not in df.columns:
        # Same-clock historical volume ratio requires multi-day intraday baseline;
        # do not substitute current cumulative volume / one bar volume as a fake volume ratio.
        df["volume_ratio"] = np.nan
    else:
        df["volume_ratio"] = pd.to_numeric(df["volume_ratio"], errors="coerce")

    cash = float(initial_cash)
    positions = {}
    trades = []
    equity_rows = []
    # Simple end-of-day mark-to-market; signals require a following bar to enter.
    for (code, day), g in df.groupby(["code","date"], sort=True):
        g = g.sort_values("datetime").reset_index(drop=True)
        # Existing position: exit on next trading day at first available open if previous day was held.
        if code in positions and positions[code]["entry_day"] != day:
            pos = positions.pop(code)
            px = float(g.iloc[0]["open"]) * (1 - 0.001)
            qty = pos["qty"]
            proceeds = px * qty
            fee = _commission(proceeds, "sell")
            cash += proceeds - fee
            pnl = (px - pos["entry_price"]) * qty - pos["entry_fee"] - fee
            trades.append({"code": code, "entry_time": pos["entry_time"], "exit_time": str(g.iloc[0]["datetime"]),
                           "entry_price": pos["entry_price"], "exit_price": px, "qty": qty,
                           "pnl": pnl, "return_pct": pnl / (pos["entry_price"] * qty) * 100,
                           "reason": "T+1次日开盘退出（保守简化）"})
        # Entry signals only when no position and there is a next bar.
        if code not in positions and len(g) > 7:
            for i in range(6, len(g)-1):
                row = g.iloc[i]
                t = row["datetime"].time()
                if not (pd.Timestamp("09:35").time() <= t <= pd.Timestamp("14:30").time()):
                    continue
                gain = row["pct_change"]
                vr = row["volume_ratio"]
                if not (5 <= gain <= 8):
                    continue
                if pd.isna(row["vwap"]) or row["close"] <= row["vwap"]:
                    continue
                if pd.isna(row["prior_high6"]) or row["close"] <= row["prior_high6"]:
                    continue
                if pd.isna(vr) or vr < 2.5:
                    continue
                nxt = g.iloc[i+1]
                entry = float(nxt["open"]) * (1 + 0.001)
                risk_budget = max(cash, 0) * risk_fraction
                stop = entry * 0.955
                qty_by_risk = int(risk_budget / max(entry - stop, 0.01) / 100) * 100
                qty_by_cap = int((cash * position_cap) / entry / 100) * 100
                qty = min(qty_by_risk, qty_by_cap)
                if qty < 100:
                    continue
                notional = entry * qty
                fee = _commission(notional, "buy")
                if notional + fee > cash:
                    continue
                cash -= notional + fee
                positions[code] = {"entry_day": day, "entry_time": str(nxt["datetime"]),
                                   "entry_price": entry, "qty": qty, "entry_fee": fee}
                break
        if len(g):
            equity_rows.append({"date": day, "cash_after_events": cash, "open_positions": len(positions)})
    trades_df = pd.DataFrame(trades)
    equity = pd.DataFrame(equity_rows).drop_duplicates("date", keep="last")
    if trades_df.empty:
        metrics = {"trades": 0, "total_return_pct": 0.0, "max_drawdown_pct": 0.0,
                   "win_rate_pct": 0.0, "profit_factor": None,
                   "warning": "没有交易；可能是缺少 volume_ratio 或信号条件过严。"}
    else:
        # Realized equity curve only; open positions are not included in final return.
        pnl_sum = float(trades_df["pnl"].sum())
        wins = trades_df.loc[trades_df["pnl"] > 0, "pnl"].sum()
        losses = -trades_df.loc[trades_df["pnl"] < 0, "pnl"].sum()
        equity["realized_equity"] = initial_cash + equity["date"].map(
            trades_df.assign(exit_day=pd.to_datetime(trades_df["exit_time"]).dt.date.astype(str))
            .groupby("exit_day")["pnl"].sum().cumsum().to_dict()).fillna(0)
        peak = equity["realized_equity"].cummax()
        dd = (equity["realized_equity"] / peak - 1).min() * 100 if len(equity) else 0
        metrics = {"trades": int(len(trades_df)),
                   "total_return_pct": pnl_sum / initial_cash * 100,
                   "max_drawdown_pct": float(dd),
                   "win_rate_pct": float((trades_df["pnl"] > 0).mean() * 100),
                   "profit_factor": float(wins / losses) if losses > 0 else None,
                   "note": "当前实现是简化研究回测；持仓估值、涨跌停排队、停牌及每日组合权益仍需进一步完善。"}
    return {"metrics": metrics, "trades": trades_df, "equity": equity}
